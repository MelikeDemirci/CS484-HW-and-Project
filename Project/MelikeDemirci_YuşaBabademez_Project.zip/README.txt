Drive link for the dataset and the saved model weights
https://drive.google.com/drive/folders/1LOo5FWM9rpyNODEL0ZZZ2xeOSqhpcFeF?usp=sharing